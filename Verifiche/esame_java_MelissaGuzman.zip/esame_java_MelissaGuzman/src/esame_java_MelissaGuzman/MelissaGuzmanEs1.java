package esame_java_MelissaGuzman;

import java.util.Scanner;

public class MelissaGuzmanEs1 {
	
	
	public static int contaLettere(String frase) {
		int totale=0;
				for(int i=0; i<frase.length(); i++) {
					if(Character.isLetter(frase.charAt(i)))
							totale++;
				}
		
		
		return totale;
	}
	
	public static int contaNumeri(String frase) {
		int totalenum = 0;
				for(int i=0; i<frase.length(); i++) {
					if(Character.isDigit(frase.charAt(i)))
						totalenum++;
				}
		
		return totalenum;
	}
	
	public static int contaSpazi(String frase) {
		int numSpazi=0;
			for(int i=0; i<frase.length(); i++)
				if(frase.charAt(i)==' ')
					numSpazi++;
		return numSpazi;
	}
	
	public static int contaAltro(String frase) {
		int count=0;
			for(int i=0; i<frase.length(); i++) {
				if((Character.isLetterOrDigit(frase.charAt(i))==false && !(frase.charAt(i)==' ')))
					count++;
			}
		
		return count;
	}
	
	public static void main(String []args) {
		Scanner tastiera=new Scanner(System.in);
		System.out.println("Dammi frase");
		String frase=tastiera.nextLine();
		System.out.println("Lettere: "+contaLettere(frase));
		System.out.println("numeri: "+contaNumeri(frase));
		System.out.println("Spazi "+contaSpazi(frase));
		System.out.println("altro: "+contaAltro(frase));
		System.out.println("lunghezza totale della Stringa "+frase.length());
		
		tastiera.close();
	}
		

}

package esame_java_MelissaGuzman;

import java.util.*;

public class Esercizio2 {

	public static void main(String[] args) {
	Scanner tastiera= new Scanner(System.in);
	Random numero= new Random();
	int randon=numero.nextInt(100);
	//System.out.println(randon); per vedere se funziona
	 int numeroT=0;
	int utente=0;
	System.out.println("Inserisci un numero");
	do {
		utente=tastiera.nextInt();
			if(utente==randon) 
				System.out.println("il numero: "+utente+" � corretto");
			else if(utente>randon)
				System.out.println("inserisci un numero piu piccolo");
			else if(utente<randon)
				System.out.println("inserisici un numero piu grande");
			else
				numeroT++;
				
				
	
	}while(utente!=randon);
	System.out.println("hai indovinato il numero in : "+numeroT);
	
	
	}
	
	

}

package verifiche;

import java.util.Random;
import java.util.Scanner;

public class MassimoRagusaEs2 {

	public static void main(String[] args) {
		int numeroDaIndovinare = 0;
		int numero = 0, tentativi = 0;
		Random r = new Random();
		Scanner sc = new Scanner(System.in);
		System.out.print("Indovinare un numero tra 1 e 100\n");
		
		numeroDaIndovinare = r.nextInt(100) + 1;
		
		do {
			System.out.println("inserire numero");
		numero = sc.nextInt();
			if (numeroDaIndovinare < numero) {
				System.out.println("Sbagliato, il numero da indovinare � pi� piccolo, riprova");
				tentativi++;
			} else if (numeroDaIndovinare> numero) {
				System.out.println("Sbagliato, il numero da indovinare � pi� grande, riprova");
				tentativi++;
			} else {
				System.out.println("Esatto!");
			}
			
		
		} while (numeroDaIndovinare != numero);

		System.out.printf("Il numero da indovinare era %d, hai fatto %d tentativi", numeroDaIndovinare, tentativi);
}
}
package verifiche;

import java.util.Scanner;

public class MassimoRagusaEs1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String stringa = "";
		int cDigit = 0, cLetter = 0, cSpace = 0, cOther = 0;
		
		System.out.println("Inserire Stringa");
		stringa = sc.nextLine();
		
		for (int i = 0; i < stringa.length(); i++) {
			char c;
			 c = stringa.charAt(i);
			
			if (Character.isDigit(c)) {
				cDigit++;
			} else if (Character.isLetter(c)) {
				cLetter++;
			} else if (c == ' ') {
				cSpace++;
			} else {
				cOther++;
			}
		
		}
		
		System.out.printf("La stringa �: %s\nlettere: %d\nspazi: %d\nnumeri: %d\naltri: %d\n", stringa, cLetter, cSpace, cDigit, cOther);
		

	}

}

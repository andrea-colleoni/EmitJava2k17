package Verifica;
import java.util.Scanner;

public class PietroFossatiEs1 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		String s;
		int lettere=0, spazi=0, numeri=0, altri=0;
		
		System.out.print("Inserisci stringa ->");
		
		s = input.nextLine().toLowerCase();
		
		for(int i = 0; i < s.length(); i++) {
			if( s.charAt(i) >= 97 && s.charAt(i) <= 122)
				lettere++;
			else if(s.charAt(i) >= 48 && s.charAt(i) <= 57)
				numeri++;
			else if(s.charAt(i) == ' ')
				spazi++;
			else
				altri++;
		}
		System.out.println("\n lettere -> " +lettere);
		System.out.println(" spazi -> " +spazi);
		System.out.println(" numeri -> " +numeri);
		System.out.println(" altri -> " +altri);
		
		input.close();
	}

}

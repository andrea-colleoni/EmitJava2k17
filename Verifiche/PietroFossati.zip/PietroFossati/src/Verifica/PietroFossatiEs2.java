package Verifica;

import java.util.Scanner;

public class PietroFossatiEs2 {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		final int limit = 100;
		int nTentativi=0, numCasuale, numero;
		
		numCasuale = (int)(Math.random()*limit);
		System.out.println("Il numero casuale � stato generato tra 0 e "+limit);
		
		do {
			System.out.print(" indovina -> ");
			numero = input.nextInt();
			nTentativi++;
			if(numCasuale != numero) {
				System.out.print("Noo, il numero � pi� ");
				if(numCasuale > numero)
					System.out.println("grande!");
				else
					System.out.println("piccolo!");
				}
		}while(numCasuale!=numero);
		input.close();
		System.out.println("\nComplimenti, il numero era proprio " + numCasuale + "!");
		System.out.println(" Ci hai messo " + nTentativi + " tentativi per indovinare");
		
	}

}

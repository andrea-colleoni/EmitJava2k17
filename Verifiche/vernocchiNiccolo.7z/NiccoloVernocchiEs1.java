
public class NiccoloVernocchiEs1 {

	public static void main(String[] args) {
		String s = "Aa kiu, I swd skieo 236587. GH kiu: sieo? 25.33";
		String[] split = s.split("");
		int numeri = 0, lettere = 0, altro = 0, spazi = 0;

		for (int i = 0; i < split.length; i++) {

			System.out.print(split[i]);
			if ((char) s.charAt(i) > 47 & (char) s.charAt(i) < 58) {
				numeri++;
			} else if (((char) s.charAt(i) > 64 & (char) s.charAt(i) < 91)
					|| ((char) s.charAt(i) > 96 & (char) s.charAt(i) < 123)) {
				lettere++;
			} else if ((char) s.charAt(i) > 32 & (char) s.charAt(i) < 65) {
				altro++;
			} else if ((char) s.charAt(i) == 32) {
				spazi++;
			}
		}

		System.out.println();
		System.out.println("Numeri " + numeri);
		System.out.println("Lettere " + lettere);
		System.out.println("Spazi " + spazi);
		System.out.println("Altri " + altro);

	}
}
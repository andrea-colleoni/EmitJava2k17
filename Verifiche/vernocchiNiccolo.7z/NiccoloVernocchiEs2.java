import java.util.Scanner;

public class NiccoloVernocchiEs2 {

	public static void main(String[] args) {
		
		int min = 1, max = 100, count = 1;
		int occaso = (int) Math.floor(Math.random() * 101);
		
		System.out.println(occaso);

		Scanner scanny = new Scanner(System.in);
		
		System.out.print("Il numero generato � uguale a: " + occaso);
			int puntata = scanny.nextInt();
			System.out.println();
		while(scanny.hasNextInt() ) {	
			
			puntata = scanny.nextInt();
		if(puntata > occaso) {
			System.out.println("Il numero generato � minore");
			count++;
			}
		else if(puntata < occaso) {System.out.println("Il numero generato � maggiore");
		count++;
		} 
		else if(puntata == occaso) {
			System.out.println("Hai indovinato");
			System.out.println(count);
		}
		}

}
}
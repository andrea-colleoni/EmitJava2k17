import java.util.Scanner;

public class MarcoCherubinEs2 {
		
	public static void main(String[] args) {
		int guess = (int)(Math.random()*100);
		
		System.out.println("Indovina il numero");
		System.out.println(guess); //stampa subito il numero random per test
		Scanner scanner = new Scanner(System.in);
		int input;
		
		do{
			input = scanner.nextInt();
			if(input>guess)
				System.out.println("Il numero da indovinare � minore");
			else if(input<guess)
				System.out.println("Il numero da indovinare � maggiore");
			else
				System.out.println("Hai indovinato!");
		}while(input!=guess);
		scanner.close();
	}
}

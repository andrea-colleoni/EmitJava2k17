import java.util.Scanner;

public class MarcoCherubinEs1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Stringa Input");
		String input = scanner.nextLine();
		scanner.close();
		int lettere=0, spazi=0, numeri=0, altri=0;
		for(int i =0; i<input.length(); i++) {
			char c=input.charAt(i);
			if((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
				lettere++;
			else if(c==' ')
				spazi++;
				else if(c>='0'&&c<='9')
					numeri++;
				else
					altri++;
		}
		
		System.out.println("La stringa �" + input);
		System.out.println("Lettere: " + lettere);
		System.out.println("Spazi: " + spazi);
		System.out.println("Numeri: " + numeri);
		System.out.println("Altri: " + altri);

	}

}

import java.util.Random;
import java.util.Scanner;

public class GiacomoLozitoEs2 {
	public static void main (String[] args){
		Scanner input = new Scanner(System.in);
		int choice = 0;
		int numeroRandom = 0;
		int numeroTentativi = 0;
		Random randomGenerator = new Random();
		numeroRandom = randomGenerator.nextInt(100);
		do{
			numeroTentativi++;
			System.out.println("Indovina numero");
			choice = input.nextInt();
			if(choice < numeroRandom) {
				System.out.println("Indizio: il numero generato e' piu' alto");
				
			}
			if(choice > numeroRandom) {
				System.out.println("Indizio: il numero generato e' piu' basso");
			}
			if(choice == numeroRandom) {
				System.out.println("Indovinato!!!!");
				break;
				
			}
		}
		while(choice != numeroRandom);
		System.out.println("Numero tentativi : " + numeroTentativi );
		
	}

}

import java.util.Scanner;

import org.omg.Messaging.SyncScopeHelper;

public class GiacomoLozitoEs1 {

	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		String choice = "";
		int contaLettere = 0, contaSpazi = 0, contaNumeri = 0, Altro = 0;
		System.out.println("Inserisci: ");
		choice = input.nextLine(); 
		
		System.out.println("La stringa e' : " + choice);
		for(int i = 0; i < choice.length(); i++ ) {
			if (choice.charAt(i) > 64 && choice.charAt(i) < 91 || (choice.charAt(i) > 96 && choice.charAt(i) < 123)) {
				
				contaLettere++;	
			} else if (choice.charAt(i) == ' '){
				contaSpazi++;
			} else if (choice.charAt(i) > 47 && choice.charAt(i) < 58){
				contaNumeri++;
			}
			else
				Altro++;
		}
		System.out.println("Lettere: " + contaLettere);
		System.out.println("Numeri: " + contaNumeri);
		System.out.println("Spazi: " + contaSpazi);
		System.out.println("Altro: " + Altro);
		
		
	}

}

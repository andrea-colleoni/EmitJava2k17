import java.util.Scanner;

public class FabioCingottiniEs1 {

	
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		String input = s.nextLine();
		int lettereTOT = 0;
		int spaziTOT = 0;
		int numeriTOT = 0;
		int altriTOT = 0;
		
		for (int i = 0; i < input.length(); i++) {
			
			char lettera = input.charAt(i);
			
			if ((lettera >= 65 && lettera <= 90)||(lettera >= 97 && lettera <= 122)||
				(lettera >= 192 && lettera <= 246)||(lettera >= 249  && lettera <= 255 )) {//lettera
				
				lettereTOT++;
			
			}else if(lettera >= 48 && lettera <= 57){//numero
				
				numeriTOT++;
			
			} else if(lettera == ' '){
			
				spaziTOT++;
			
			}else {
				altriTOT++;
			}
		}
		
		System.out.println("La stringa �: " + input);
		System.out.println("lettere: " + lettereTOT);
		System.out.println("spazi: " + spaziTOT);
		System.out.println("numeri: " + numeriTOT);
		System.out.println("altri: " + altriTOT);
	}

}

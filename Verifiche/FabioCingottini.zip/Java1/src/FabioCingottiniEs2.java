import java.util.Scanner;

public class FabioCingottiniEs2 {

	public static void main(String[] args) {
		
		int numeroDaIndovinare = FabioCingottiniEs2.generaIntRandom(100);
		int tentativi = 0;
		
		while (true) {
			
			System.out.println("Indovina il numero... � compreso tra 1 e 100 (compresi)");
			
			int numero = FabioCingottiniEs2.scannerInt();
			
			if (numero == numeroDaIndovinare) {
				System.out.println("Complimenti... ci sono voluti " + tentativi + " tentativi"
						+ " per indovinare");
				System.out.println("");
				break;
			
			} else if (numero > numeroDaIndovinare) {
				System.out.println("Sbagliato.. il numero che stai cercando di scoprire � minore "
						+ "di quello che hai inserito");
				System.out.println("");
				tentativi++;
			
			} else if (numero < numeroDaIndovinare) {
				System.out.println("Sbagliato.. il numero che stai cercando di scoprire � maggiore "
						+ "di quello che hai inserito");
				System.out.println("");
				tentativi++;
			}		
		}
		
		System.out.println("#Programma terminato");
		
	}	
	
	public static int scannerInt() {
	    Scanner sc = new Scanner(System.in);
	    while (true) {
	        try {
	        	return sc.nextInt();
	        }
	        catch (java.util.InputMismatchException e) {	        
	            System.out.println("non � un numero, inserisci un numero");
	            System.out.println();
	            return scannerInt();
	        }
	    }
	}
	
	public static int generaIntRandom(int numMax) {
		int numero = (int)(numMax * Math.random()); 
		return numero;
	}	
}

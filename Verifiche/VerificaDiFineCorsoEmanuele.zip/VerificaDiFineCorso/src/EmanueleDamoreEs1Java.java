import java.util.Scanner;

public class EmanueleDamoreEs1Java {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		int lettere = 0;
		int spazi = 0;
		int numeri = 0;
		int altri = 0;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);

			if (c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z') {
				lettere++;

			} else if (c == ' ') {
				spazi++;

			} else if (c >= '0' && c <= '9') {
				numeri++;

			} else {
				
					altri++;
			}

		}

		System.out.println("La stringa �: " + s);
		System.out.println("lettere: " + lettere);
		System.out.println("spazi: " + spazi);
		System.out.println("numeri: " + numeri);
		System.out.println("altri: " + altri);
	}
}

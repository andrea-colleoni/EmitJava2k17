import java.util.Random;
import java.util.Scanner;

public class EmanueleDamoreEs2 {

	public static void main(String[] args) {

		Random r = new Random();

		Scanner sc = new Scanner(System.in);
		int numero;
		int numeroRandom = r.nextInt(100) + 1;

		do {

			System.out.println("inserisci numero tra 1 e 100: ");

			numero = sc.nextInt();

			if (numero == numeroRandom) {
				System.out.println("Hai indovinato!!!!");

			} else if (numero < numeroRandom) {
				System.out.println("Il numero random maggiore");

			} else if (numero > numeroRandom) {
				System.out.println("Il numero random minore");

			}else {
				
			}

		} while (numero != numeroRandom);

	}
}

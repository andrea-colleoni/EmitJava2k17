package verifica;

import java.util.Scanner;

public class MarzioMarinoEs2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Indovina un numero da 1 a 100");
		
		Scanner input = new Scanner(System.in);
		int n = (int)(Math.random()*100)+1;
		int tentativi = 0;
		int risposta = 0;
		while(true) {
			
			tentativi++;
			risposta = input.nextInt();
			
			if( risposta == n) {
				System.out.println("Bravo! Hai indovinato in " + tentativi + " tentativi");
				break;
			}else {
				System.out.println("Non hai indovinato.. riprova pi� "
						+  ((risposta>n)?"basso":"alto") );
			}
			
		}
	}

}

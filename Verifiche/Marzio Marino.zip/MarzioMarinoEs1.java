package verifica;

import java.util.Scanner;

public class MarzioMarinoEs1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		String s = input.nextLine();
		
		int lettere = 0, spazi = 0, numeri = 0, altri = 0;
		
		for(char c: s.toCharArray()) {
			
			if(c>64 && c<122) {
				lettere++;
			}else if(c>47 && c<58) {
			    numeri++;
			}else if(c == ' ') {
				spazi++;
			}else {
				altri++;
			}
			
		}
		
		System.out.print("La stringa �: " + s       + "\n" +
						 "lettere: "      + lettere + "\n" +
						 "spazi: "        + spazi   + "\n" +
						 "numeri: "       + numeri  + "\n" +
						 "altri: "        + altri);
	}

}

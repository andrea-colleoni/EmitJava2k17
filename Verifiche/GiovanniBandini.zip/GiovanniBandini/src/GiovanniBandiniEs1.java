import java.util.Scanner;

public class GiovanniBandiniEs1 {

	public static void main(String[] args) {
		
		int l=0;
		int n=0;
		int s=0;
		int a=0;
		
		System.out.println("Inserire la strringa");
		Scanner inputTastiera = new Scanner (System.in);
		String stringa = inputTastiera.nextLine();
		
		System.out.println("La stringa �: " + stringa);
		
		for ( int i=0; i < stringa.length(); i++){
			Character c= stringa.charAt(i);
			if( Character.isLetter(c)) {
				l++;
			} else if( Character.isDigit(c)) {
				n++;
			} else if( Character.isWhitespace(c)) {
				s++;
			} else {
				a++;}
		}	
		System.out.println("Lettere: " + l);
		System.out.println("Numeri: " + n);		
		System.out.println("Spazi : " + s);		
		System.out.println("Altro: " + a);		
		

	}

}

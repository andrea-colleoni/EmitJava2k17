import java.util.Scanner;

public class LorenzoAmprinoEs1 {

	public static void main(String[] args) {
		int lettere = 0;
		int numeri = 0;
		int spazi = 0;
		int altro = 0;

		Scanner sc = new Scanner(System.in);
		System.out.println("Inserire stringa da analizzare:");
		String input = sc.nextLine();

		System.out.println(input.length());

		for (int i = 0; i < input.length(); i++) {
			Character c = input.charAt(i);
			if (Character.isLetter(c))
				lettere++;
			else if (Character.isDigit(c))
				numeri++;
			else if (Character.isWhitespace(c))
				spazi++;
			else
				altro++;

		}
		System.out.println("Lettere: " + lettere);
		System.out.println("Numeri: " + numeri);
		System.out.println("Spazi: " + spazi);
		System.out.println("Altro: " + altro);
		sc.close();
	}
}

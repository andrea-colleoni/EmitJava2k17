import java.util.Scanner;

public class LorenzoAmprinoEs2 {

	public static void main(String[] args) {
		int tentativi = 1;
		boolean giusto = false;
		int numeroDaIndovinare = ((int)(Math.random()*100 + 1));
		
		Scanner sc = new Scanner(System.in);
		System.out.println("indovina il numero da 1 a 100");
		int numero = sc.nextInt();
		do {
		if(numero>numeroDaIndovinare) {
			System.out.println("il numero da indovinare � pi� piccolo di " + numero);
			tentativi++;
			numero = sc.nextInt();
		}
		else if (numero<numeroDaIndovinare) {
			System.out.println("il numero da indovinare � pi� grande di " + numero);
			tentativi++;
			numero = sc.nextInt();
		}
		else {
			System.out.println("CORRETTO! hai impegato " + tentativi + " per indovinare.");
			giusto = true;
		}
		}while(!giusto);
	}

}

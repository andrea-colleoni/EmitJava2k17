package Programma;
import java.util.Scanner;

public class DomenicoSicilianoEs1 {
	public static void main(String[]args) {
	 Scanner input = new Scanner(System.in);
	 
	 int contatoreLettere = 0;
	 int contatoreSpazi = 0;
	 int contatoreNumeri = 0;
	 int contatoreAltri = 0;
	 
	 System.out.println("Digitare la stringa da analizzare:");
	 String oggettoAnalisi = input.nextLine();
	 
	 for (int i=0; i<oggettoAnalisi.length(); i++) {
	 char analizzato = oggettoAnalisi.charAt(i);
	  if (Character.isLetter(analizzato)){
		  contatoreLettere++;
	  } 
	  else if (analizzato == ' ')
	  {
	   contatoreSpazi++;
		  
	  }
	  else if (Character.isDigit(analizzato)){
		  contatoreNumeri++;
	  } else {
		  contatoreAltri++;
	  }
	  
	 }
	 System.out.println("La stringa �: "+oggettoAnalisi);
	  System.out.println("lettere: "+ contatoreLettere);
	  System.out.println("spazi: "+ contatoreSpazi);
	  System.out.println("numeri: "+ contatoreNumeri);
	  System.out.println("altri: "+ contatoreAltri);
	 
	  input.close();
	  
	}
}

package Programma;

import java.util.Scanner;

public class DomenicoSicilianoEs2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("***********************************");
		System.out.println("* Benvenuto ad Indovina il Numero *");
		System.out.println("***********************************");
		System.out.println("Prova ad indovinare il numero da 1 a 100");
		
		int jackpot = (int)(Math.random()*(100 - 1));
		int contatore = 0;

		try {
	    int tentativo = input.nextInt();
		while(tentativo != jackpot) {
		if (tentativo <jackpot) {
			System.out.println("Il numero da te scelto � troppo basso. Ritenta!");
			contatore++;
			tentativo = input.nextInt();
		} else {
			System.out.println("Il numero da te scelto � troppo alto. Ritenta!");
			contatore++;
			tentativo = input.nextInt();
		}
		}
		System.out.println("*********************");
		System.out.println("* Bravo, hai vinto! *");
		System.out.println("*********************");
		System.out.println("Ci hai messo solo "+contatore+" tentativi!");
        input.close();		
		}
		catch (Exception e) {
			System.out.println("Valore inserito non valido!");
		}
	}

}

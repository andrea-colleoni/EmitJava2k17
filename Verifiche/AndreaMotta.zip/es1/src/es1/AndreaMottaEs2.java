package es1;

import java.util.Scanner;

public class AndreaMottaEs2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
//		do {
		int numRandom = (int)((Math.random() * 99) + 1);
//		System.out.println(numRandom);
//		}while(true);
		System.out.println("indovina il numero compreso tra 1 e 100");
		int cont = 0;
		String numero;
		boolean controllo = false;
		int num = 0;

		do {
			System.out.println("inserisci un numero");
			do {
				numero = sc.next();
				try {
					num = Integer.parseInt(numero);
					controllo = true;
				} catch (Exception e) {
					System.out.println("numero inserito non valido");
				}
			} while (controllo == false);
			cont += 1;
			if (num < numRandom)
				System.out.println("il numero da indovinare � maggiore");
			if (num > numRandom)
				System.out.println("il numero da indovinare � minore");
		} while (num != numRandom);

		System.out.println("bravo hai indovinato il numero in " + cont + " tentativi");

		sc.close();

	}

}

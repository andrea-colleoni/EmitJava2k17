package es1;

import java.util.Scanner;

public class AndreaMottaEs1 {

	public static void main(String[] args) {

		System.out.println("Inserrire stringa");
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();

		System.out.println("La stringa �: " + s);
		int contatoreNumeri = 0;
		int contatoreSpazi = 0;
		int contatoreLettere = 0;
		int contatoreAltri = 0;

		for (int i = 0; i < s.length(); i++) {
			if ((s.charAt(i) > 64 && s.charAt(i) < 91) || (s.charAt(i) > 96 && s.charAt(i) < 123))
				contatoreLettere += 1;
			else {
				if (s.charAt(i) == ' ') {
					contatoreSpazi += 1;
				} else {
					if (s.charAt(i) > 47 && s.charAt(i) < 58)
						contatoreNumeri += 1;
					else
						contatoreAltri += 1;
				}

			}
		}
		System.out.println("Lettere: " + contatoreLettere + "\nSpazi :" + contatoreSpazi);
		System.out.println("Numeri : " + contatoreNumeri + "\nAltri :" + contatoreAltri);

		sc.close();

	}

}
